import {  Main, Product, Footer, Team } from "../components";

function Home() {
  return (
    <>
     
      <Main />
      <Footer />
    </>
  )
}

export default Home
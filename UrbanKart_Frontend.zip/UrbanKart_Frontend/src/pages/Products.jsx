import React from 'react'
import { Footer, Product } from "../components"

const Products = () => {
  return (
    <>
     
      <Product />
      <Footer />
    </>
  )
}

export default Products
export default class Orderstatus {
    constructor(orderId ,status , deliveryDate){
        this.orderId = orderId
        this.status=status
    }
}
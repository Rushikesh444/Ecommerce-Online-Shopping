export default class Category {
    constructor(id,name) {
      this.name = name;
      this.id = id;
      //  this.url = url;
    }
  }
  